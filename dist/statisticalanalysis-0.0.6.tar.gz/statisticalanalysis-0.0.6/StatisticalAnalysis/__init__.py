"""A pypi demonstration vehicle.

.. moduleauthor:: Andrew Carter <andrew@invalid.com>

"""

from .statisticalComparison import *

__all__ = ['compare_methods']
